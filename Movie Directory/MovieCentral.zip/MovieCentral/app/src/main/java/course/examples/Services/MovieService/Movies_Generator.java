package course.examples.Services.MovieService;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import course.examples.Services.MovieCommon.MovieGenerator;

public class Movies_Generator extends Service {

	// Set of already assigned IDs
	// Note: These keys are not guaranteed to be unique if the Service is killed 
	// and restarted.

		private final String[][] allMoviesInfo =
			{
					{"Interstellar","Christopher Nolan","https://www.youtube.com/watch?v=2LqzF5WauAw&ab_channel=InterstellarMovie"},
					{"Avengers Endgame","Russo Brothers","https://www.youtube.com/watch?v=TcMBFSGVi1c&ab_channel=MarvelEntertainment"},
					{"Jojo Rabbit","Taika Waititi","https://www.youtube.com/watch?v=tL4McUzXfFI"},
					{"Up","Pete Docter","https://www.youtube.com/watch?v=ORFWdXl_zJ4"},
					{"Hacksaw Ridge","Mel Gibson","https://www.youtube.com/watch?v=s2-1hz1juBI"}
			};
	private String[] moviesList = {"Interstellar", "Avengers Endgame", "Jojo Rabbit", "Up", "Hacksaw Ridge"};
	private String[] directorsList = {"Christopher Nolan", "Russo Brothers", "Taika Waititi", "Pete Docter", "Mel Gibson"};
	private String[] urlList = {"https://www.youtube.com/watch?v=2LqzF5WauAw&ab_channel=InterstellarMovie",
			"https://www.youtube.com/watch?v=TcMBFSGVi1c&ab_channel=MarvelEntertainment",
			"https://www.youtube.com/watch?v=tL4McUzXfFI",
			"https://www.youtube.com/watch?v=ORFWdXl_zJ4",
			"https://www.youtube.com/watch?v=s2-1hz1juBI"};




	// Implement the Stub for this Object
	private final MovieGenerator.Stub mBinder = new MovieGenerator.Stub() {
		@Override
		public Bundle allInformation() throws RemoteException {
			Bundle bundle=new Bundle();
			bundle.putSerializable("allMoviesInfo", allMoviesInfo);
			return bundle;
		}

		// Implement the remote method
		public String[] getMoviesList() {
			checkCallingPermission("course.examples.Services.MovieService.GEN_ID");
			return moviesList;
		}

		@Override
		public String[] getDirectorsList() throws RemoteException {
			checkCallingPermission("course.examples.Services.MovieService.GEN_ID");
			return directorsList;
		}

		@Override
		public String[] getURLList() throws RemoteException {
			return urlList;
		}

		@Override
		public String getURLbyID(int id) throws RemoteException {
			return urlList[id];
		}

		@Override
		public String[] getMovieInfoByID(int id) throws RemoteException {
			return allMoviesInfo[id];
		}
	};
	// Return the Stub defined above
	@Override
	public IBinder onBind(Intent intent) {
		return mBinder;
	}
}

