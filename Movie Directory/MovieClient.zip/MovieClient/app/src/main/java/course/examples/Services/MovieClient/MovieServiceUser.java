package course.examples.Services.MovieClient;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import course.examples.Services.MovieCommon.MovieGenerator;

public class MovieServiceUser extends Activity {

	protected static final int PERMISSION_REQUEST = 0;
	private MovieGenerator mMovieGeneratorService;
	private boolean mIsBound = false;
	private Button bind;
	private Button unbind;
	private TextView bindStatus;
	private Button details;
	private Spinner clipsSpinner;
	private Spinner detailsSpinner;
	private String[] movieNumber={"Select Movie here","1st Movie","2nd Movie","3rd Movie","4th Movie","5th Movie"};
	private int runTimes=0;

	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.main);

		bind=findViewById(R.id.Bind);
		unbind=findViewById(R.id.unbind);
		bindStatus=findViewById(R.id.bindStatus);
		details=findViewById(R.id.details);
		clipsSpinner=findViewById(R.id.clipsSpinner);
		detailsSpinner=findViewById(R.id.detailsSpinner);

		details.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				if(mIsBound) {
					Intent intent = new Intent(MovieServiceUser.this, ListViewMovies.class);
					try {
						intent.putExtras(mMovieGeneratorService.allInformation());
					} catch (RemoteException e) {
						e.printStackTrace();
					}
					startActivity(intent);
				}
				else {
						Toast.makeText(getApplicationContext(),"Bind to the service first",Toast.LENGTH_LONG).show();
				}
			}
		});


		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, movieNumber);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		clipsSpinner.setAdapter(adapter);
		detailsSpinner.setAdapter(adapter);
		clipsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
				if(!mIsBound){
					if(runTimes<2){
						runTimes++;
					}else{
						Toast.makeText(getApplicationContext(),"Bind to the service first",Toast.LENGTH_LONG).show();
					}
//					Toast.makeText(getApplicationContext(),"Bind to the service first",Toast.LENGTH_LONG).show();
					clipsSpinner.setSelection(0);
					return;
				}
				switch (position){
					case 0:
						break;
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
						Intent clipIntent=new Intent(MovieServiceUser.this,clipDisplay.class);
						clipsSpinner.setSelection(0);
						try {
							clipIntent.putExtra("URL",mMovieGeneratorService.getURLbyID(position-1));
							startActivity(clipIntent);
						} catch (RemoteException e) {
							e.printStackTrace();
						}
						break;
				}
			}
			@Override
			public void onNothingSelected(AdapterView<?> adapterView) {

			}
		});
		detailsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
				if(!mIsBound){
					if(runTimes<2){
						runTimes++;
					}else{
						Toast.makeText(getApplicationContext(),"Bind to the service first",Toast.LENGTH_LONG).show();
					}
//					Toast.makeText(getApplicationContext(),"Bind to the service first",Toast.LENGTH_LONG).show();
					detailsSpinner.setSelection(0);
					return;
				}
				switch (position){
					case 0:
						break;
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
						Intent detailsIntent=new Intent(MovieServiceUser.this,DetailsView.class);
						detailsSpinner.setSelection(0);
						try {
							detailsIntent.putExtra("MovieDetails",mMovieGeneratorService.getMovieInfoByID(position-1));
							startActivity(detailsIntent);
						} catch (RemoteException e) {
							e.printStackTrace();
						}
						break;
				}
			}
			@Override
			public void onNothingSelected(AdapterView<?> adapterView) {

			}
		});

	}

	// Bind to KeyGenerator Service
	@Override
	protected void onStart() {
		super.onStart();

		bind.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				if(!mIsBound){
					if (checkSelfPermission("course.examples.Services.MovieService.GEN_ID")
							!= PackageManager.PERMISSION_GRANTED) {
						ActivityCompat.requestPermissions(MovieServiceUser.this,
								new String[]{"course.examples.Services.MovieService.GEN_ID"},
								PERMISSION_REQUEST);
					}
					else {
						checkBindingAndBind();
					}
				}
			}
		});

		unbind.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				if(mIsBound){
					unbindService(mConnection);
					bindStatus.setText("Unbound");
					mIsBound=false;
				}
			}
		});

	}

	protected void checkBindingAndBind() {
		if (!mIsBound) {

			boolean b = false;
			Intent i = new Intent(MovieGenerator.class.getName());

			// UB:  Stoooopid Android API-21 no longer supports implicit intents
			// to bind to a service #@%^!@..&**!@
			// Must make intent explicit or lower target API level to 20.
			ResolveInfo info = getPackageManager().resolveService(i, 0);
			i.setComponent(new ComponentName(info.serviceInfo.packageName, info.serviceInfo.name));

			b = bindService(i, this.mConnection, Context.BIND_AUTO_CREATE);
			if (b) {
				Log.i("Harsh", "bindService() succeeded!");
			} else {
				Log.i("Harsh", "bindService() failed!");
			}
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		switch (requestCode) {
			case PERMISSION_REQUEST: {

				if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

					// Permission granted, go ahead and display map

					checkBindingAndBind();
				}
				else {
					Toast.makeText(this, "BUMMER: No Permission :-(", Toast.LENGTH_LONG).show() ;
				}
			}
			default: {
				// do nothing
			}
		}
	}
	// Unbind from KeyGenerator Service
	@Override
	protected void onStop() {

		super.onStop();

//		if (mIsBound) {
//			unbindService(this.mConnection);
//			mIsBound=false;
//			bindStatus.setText("Unbound");
//		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (mIsBound) {
			unbindService(this.mConnection);
			mIsBound=false;
			bindStatus.setText("Unbound");
		}
	}

	private final ServiceConnection mConnection = new ServiceConnection() {

		public void onServiceConnected(ComponentName className, IBinder iservice) {

			mMovieGeneratorService = MovieGenerator.Stub.asInterface(iservice);

			mIsBound = true;
			bindStatus.setText("Bound");
		}

		public void onServiceDisconnected(ComponentName className) {

			mMovieGeneratorService = null;
			bindStatus.setText("Unbound");
			mIsBound = false;

		}
	};

	@Override
	public void onResume() {
		super.onResume();

	}

	@Override
	public void onPause() {
		super.onPause();
	}
}
