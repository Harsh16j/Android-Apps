package course.examples.Services.MovieClient;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ListViewMovies extends ListActivity {
    private ListView listView;
    private String[][] allMoviesInfo;
    private String[] str;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        allMoviesInfo=(String[][]) getIntent().getExtras().getSerializable("allMoviesInfo");

        str=new String[allMoviesInfo.length];
        for(int i=0;i<allMoviesInfo.length;i++){
            str[i]=allMoviesInfo[i][0]+", "+allMoviesInfo[i][1];
        }
        listView=getListView();
        setListAdapter(new ArrayAdapter<String>(this,R.layout.title_item,str));
        listView.setTextFilterEnabled(true);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        Intent clipIntent=new Intent(ListViewMovies.this,clipDisplay.class);
        clipIntent.putExtra("URL",allMoviesInfo[position][2]);
        startActivity(clipIntent);
    }
}