package course.examples.Services.MovieClient;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DetailsView extends Activity {
    TextView title,director,url;
    String[] movieDetails;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_view);
        title=findViewById(R.id.titleMovie);
        director=findViewById(R.id.director);
        url=findViewById(R.id.url);
        movieDetails=getIntent().getStringArrayExtra("MovieDetails");
        title.setText(movieDetails[0]);
        director.setText(movieDetails[1]);
        url.setText(movieDetails[2]);

    }
}